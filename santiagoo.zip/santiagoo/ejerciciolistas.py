#EJERCICIOS LISTAS
valor_a = 5
#            0  1  2  3  4   5         
valor_lista=[4, 7, 8, 9, 10, 20, 30, 40, 55]
print(valor_lista[2])

#Ejercicios_lista_texto

lista2=["Saludo", "Juan" , "Estudiante","Incap" ]
print(lista2)

#Ejercicio_lista_aplicaion_append
lista2_append=("Prueba")
print(lista2_append)

#Ejercicio_lista_aplicaion_pop
lista2.pop()
print(lista2)
#Ejercicio_lista_aplicaion_clear
lista2.clear()
print(lista2)
